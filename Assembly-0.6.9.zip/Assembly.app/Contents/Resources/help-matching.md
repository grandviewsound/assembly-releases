# Matching

Select what you want in Pro Tools, then choose one of these in step 2, or from the toolbar's **Match** button:

- **Match Selected Clips** (⇧⌘M) — the clips on the selected tracks that fall inside the edit selection.
- **Match Selected Tracks** — every clip on the selected tracks, end to end.

Assembly never widens a selection. If nothing is selected it says so; it never falls back to the whole session. To match a whole session, select all of it in Pro Tools first.

## How a clip is matched

For each clip, Assembly listens to the clip's own audio, finds the roll and the channel it came from in the deep scan, and measures exactly where in that roll it starts. A match needs the audio to agree. Clip names and timecode can help find likely rolls sooner, but they never make a match on their own.

If a picture editor's turnover carries each mic on its own track, selecting all of them finds each take once, not once per mic.

## Reading the results

Step 2 shows how many clips matched and how many didn't, with a preview of the tracks an assembly would build. **View Matches**, or **Window ▸ Match Detail** (⌘3), lists every clip with its roll and channel, and for anything unmatched, the reason.

Common reasons a clip doesn't match:

- Its roll isn't in the scanned folder — a different drive, or a card that hasn't been deep scanned yet.
- It isn't production sound: music, effects, or a mix that isn't on any roll.
- Its audio is too short, too quiet or too processed to identify with confidence.
- Its media is offline, or macOS refused access. See [Files and Permissions](help:file-access).

> Clips that Assembly itself assembled can't be matched again: they share their names with their rolls. Match the original guide clips instead.
