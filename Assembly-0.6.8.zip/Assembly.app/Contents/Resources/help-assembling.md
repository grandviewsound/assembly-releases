# Assembling

After a match, step 3 holds the options for building it. The track preview in step 2 follows the options that change the layout, so you can see the tracks before anything is written.

## Options

- **Tracks By** — **Channel Name** gives each microphone its own track. **Channel Number** keeps each channel position of the rolls on one track.
- **Smart Grouping** — orders tracks by role: Mix, Boom, Lav, Plant, then Other. **Reorder Options…** changes the order.
- **Name Prefix**, **Track Color** and **Track Height** — for the new tracks.
- **Clip Colors** — color each clip by the kind of microphone it came from. The kind is read from the channel's name, so a radio mic named after its actor counts as a lav.
- **Lay down duplicate takes** — whether a take used on more than one selected track is laid down once, or each time.
- **Keep reference clip mute** and **Start clips muted by role** — which new clips start muted.
- **Create report track** — adds a track of labeled ranges flagging anything that needs a look.
- **Fades** — recreate the edit's fades and crossfades. Pro Tools doesn't report which fade shape was used, so choose one.
- **Add Scene & Shot Tracks** — build picture reference from an EDL, once, with this assembly. See [Picture Tracks from an EDL](help:picture-tracks).

## Assemble

Choose **Assemble**. A review lists every operation before anything is sent to Pro Tools. Assembly then:

1. Checks that the same session is still open.
2. Adds the sound rolls to the session's Clip List — referenced where they are, never copied.
3. Creates a clip for each exact range of each roll.
4. Creates the new tracks.
5. Places every clip at its exact sample position.

Each clip lands where its original sits, at its own length. Nothing is moved or stretched to close a gap.

You can stop a run part-way; whatever has been written stays in the session. When it finishes, a summary lists anything that wasn't done. An extra — a color, a fade, the report track — can be skipped without stopping the run.

> To assemble again, match again. A plan is used once: after a run, the session has changed underneath it.
