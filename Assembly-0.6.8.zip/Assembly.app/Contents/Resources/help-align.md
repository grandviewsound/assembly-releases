# Aligning Lavs to the Boom

**Session ▸ Align Selected Clips (Experimental)** lines up the radio mics with the boom, in time and in phase, so they sit together without comb filtering. The **Align** button in the main window's toolbar offers it too, beside **Batch Align Sound Rolls (Experimental)…**.

In Pro Tools, select the assembled clips you want aligned, and each take's boom with them: the lowest-numbered boom in a take is what the rest of it is aligned to. Then choose **Align Selected Clips (Experimental)**. A sheet shows what will happen before anything is written.

To align whole sound rolls instead, without Pro Tools, see **Batch aligning sound rolls** below.

## What it does

- Each lav is aligned to a boom of its take, in one of three ways — see **Mode** below.
- The aligned audio is written as new files in the session's Audio Files folder, named like an AudioSuite render: the clip's name followed by `-ALN_01`.
- The new files keep the roll's metadata, but get an identity of their own, so Pro Tools never relinks them to the original roll.
- The aligned set goes on new tracks, with each take's booms laid down unchanged beside it — or, when the booms are aligned to each other, aligned too.

The original clips and the sound rolls are never touched.

## Options

- **Mode** — what the take is aligned to. A take with one boom aligns to it the same way in every mode.
  - **Boom 1** — every lav, and Boom 2, is aligned to the take's Boom 1.
  - **Most prominent boom (Experimental)** — moment to moment, each lav follows whichever boom is leading: the one standing furthest above its own background noise, counted only where it is hearing the same scene as the take's other mics. It crossfades where that changes. The booms are left as recorded.
  - **Most prominent boom, booms aligned (Experimental)** — the same, and the booms are aligned to each other: the leading boom stays as recorded, and the other boom is aligned to it. Where the lead changes, they trade places, so at every moment the whole take lines up with the boom carrying the scene.
- **Handles** — how many seconds of extra audio, up to 60, to align and write either side of each clip.
- **File name** and **Track name** — the names for the new files and tracks.
- **Folder** — put the aligned set in a folder track.
- **Report** — add a report track marking anything to look at. See **The report track** below.
- **Track color** and **Clip color** — including a color for each kind of mic.

## Clips left alone

Some clips are left exactly as they are rather than moved on a guess:

- No boom from its take is in the selection.
- The boom gives nothing to align to — a dead boom, or one that never hears that actor.

The sheet lists how many clips are left alone and why, and the diagnostic report names each one. If nothing in the selection can be aligned, an alert says why and the session isn't changed.

Following the most prominent boom, a silent boom is passed over, and so is a boom that hears nothing the take's other mics hear, however loud it is. When the booms are wired the other way round from each other, Boom 1 leads the whole take, since following both would flip the channels at every change. The report says which, take by take.

## The report track

After an alignment, a track named like **ALN Report** sits below your selection, with an empty clip at each place worth looking at, named for what happened:

- **NOT ALIGNED** — refused before any audio was read. A clip with a problem such as no boom in its take, or a name that doesn't say which channel it plays.
- **LEFT ALONE** — read, and deliberately not changed, such as a silent channel or a boom that never hears that mic.
- **FAILED** — could not be rendered.
- **CHECK** — aligned, but listen here first: the delay measured from only a small part of the clip, samples over full scale, or a damaged roll.

A take's mics all share one time range, so each take gets one entry saying how many clips and why: `NOT ALIGNED 3 · no boom in take · C68P04T01`. **Save Diagnostic Report…** lists every clip behind every entry.

Mix tracks, booms doing their job, and other clips left out on purpose aren't marked, and neither is a lav whose polarity was turned over to match its boom, which is routine. If there is nothing to report, or nothing was aligned, no track is added.

## Batch aligning sound rolls

**Session ▸ Batch Align Sound Rolls (Experimental)…**, or the toolbar's **Align** button, aligns the lavs of whole rolls, with no session and no Pro Tools. It works through the rolls the last **Scan Sound Rolls** found. It is new: try a small folder first and check what it writes.

1. Tick the folders to align. A folder takes in everything below it, so start with one small folder — a day, or a card — and listen before doing the rest.
2. **Choose…** a destination outside the sound rolls folder.
3. Set the **File name** text and the **Mode** — the same three modes as in Align Selected Clips.
4. Choose **Align**.

Each roll is written to the destination in the same folders as in the sound rolls folder:

- Its name gets the **File name** text: `C12P02T01.WAV` becomes `C12P02T01-ALN.WAV`.
- Its lavs and plants are aligned over the whole roll, and its booms too in the **Boom 1** and **booms aligned** modes. The mix, timecode and any channel without a name stay exactly as recorded, sample for sample.
- Every channel and all the roll's metadata are kept: scene, take, tape, notes, track names, time stamp and the rest. Only its identity is new — a new UMID and file ID, so Pro Tools never relinks it as the original roll — and its coding history gains a line saying what was aligned to what.
- It stays at the roll's bit depth, unless aligned audio goes past full scale; then the copy is 32-bit float, so nothing clips.

A whole roll is aligned in one go, so the memory it needs grows with its length. A roll too long for this Mac's memory — over 12 minutes on 8 GB, 24 minutes on 16 GB, 30 minutes from 20 GB — is listed as having nothing to align, with the reason; align it as clips in Pro Tools instead.

Channels are read by the names the recorder gave them, so a roll needs a channel named as a boom. The window lists why any roll has nothing to align. **Copy rolls with nothing to align** puts those in the destination unchanged, under their own names, so it holds every roll.

A roll already in the destination is never replaced. **Stop** keeps every finished roll and nothing of the one under way, so choosing **Align** again carries on where it stopped. The sound rolls themselves are only ever read.

When a run finishes, **Save Diagnostic Report…** saves what it did: how each roll's channels were read, what happened to each channel, and each new roll read back against the original to show its metadata and untouched channels were kept.
