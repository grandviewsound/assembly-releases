# Picture Tracks from an EDL

**Session ▸ Build Picture Tracks from EDL…** (⇧⌘P) reads the picture editor's CMX3600 list and builds reference tracks in the session: a **Scene** track and a **Shot** track, one clip per cut.

## The choices

- **How the clips get in:**
  - **Clip group files — no media, with color.** Assembly writes a clip group file for each track; drag them into the session. Pro Tools can't take a clip group any other way.
  - **Empty clip groups — no media, no color.** Built straight into the session.
  - **Cut from a silent file — with color.** Built straight into the session from one silent file.
- **Place at** — the list's own timecode, or moved so the list starts at the session start. A reel usually begins at 01:00:00:00; a session needn't. Assembly checks the list lands inside the session before writing anything.
- **Script** — add the shooting script as a PDF, and scene clips are named with their scene headings. Assembly remembers the script for later reels, so check it when you change shows: a warning appears if it names almost none of the cut's scenes, which usually means it's another show's. **Clear** removes it.
- **Scene color** — **Each scene its own** gives every scene a color of its own. **INT / EXT** colors each scene by where its script heading sets it: one color for INT, one for EXT, one for INT/EXT. Click a swatch to choose its color, or click the round arrow for three new random colors, as often as you like. It needs a script; a scene the script doesn't have is left uncolored. Shots set to **Same as its scene**, and **Shades of the scene color**, follow it.
- **Angles**, **Shot color** and **Shades of the scene color** — how shots are colored, by camera angle or by scene.
- **Dissolves** — cut at the list's own boundary, at the midpoint, or at the end.

The frame rate comes from the session, because an EDL doesn't state its own. Each clip lands at exactly the record time and length its event says.

## Building with an assembly

**Add Scene & Shot Tracks** in step 3 opens the same choices and builds the picture tracks once, together with the assembly, above the assembled tracks.

## Batch export

**Session ▸ Batch Export Picture Tracks from EDLs…** writes clip group files for many lists at once. It doesn't need Pro Tools. If Assembly is already connected, the frame rate and sample rate start from the open session's; otherwise they start at 24 fps and 48 kHz. Check both in the review either way. When the file names say which reel (R1, R2…) or episode (Ep 101…) each list is, the files can be sorted into a folder per reel or episode; the review shows every file's folder before anything is written.
