# Connecting to Pro Tools

Assembly talks to Pro Tools directly; there is nothing to export first. Matching connects by itself, so most of the time you never think about it.

- Pro Tools must be running on this Mac with the session open: version 2025.06 or later.
- **Session ▸ Connect to Pro Tools** (⌘R) connects now. Once connected, step 2 shows the session's name.
- If it can't connect, step 2 says why. **Details** shows the full message; it is also in a diagnostic report.

## Changing sessions

A match belongs to the session it was made in. If you open a different session in Pro Tools, match again. Before writing anything, Assembly checks that the same session is still open, and stops if it isn't.

## Older versions of Pro Tools

A few extras need a newer Pro Tools than the rest: clip and track colors need 2025.10, and track heights 2025.12. On an older version they are left out, and the review before assembling shows what will actually happen.
