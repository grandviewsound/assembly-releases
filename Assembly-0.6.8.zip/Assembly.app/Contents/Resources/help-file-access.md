# Files and Permissions

Assembly reads sound rolls and session media wherever they are. The first time it needs files in a protected place, macOS asks once for that whole area: the Desktop, Documents, Downloads, removable volumes, or network volumes. Choose **Allow**.

## When access is refused

Assembly tells you whose refusal it is, and offers the fix:

- **macOS refused** — a permission prompt was answered Don't Allow. Choose **Open System Settings**, go to **Privacy & Security ▸ Files and Folders**, and turn on Assembly's switch for that area.
- **The files' own permissions refused** — choose **Show in Finder**, then **File ▸ Get Info ▸ Sharing & Permissions** to give your account read access.

Before matching, Assembly checks that it can read the selected clips' media and a few of the rolls, and stops with an alert if it can't — so you find out before a long match, not after.

**Session ▸ Grant Access to Session Media…** lets you grant a folder directly, if a prompt didn't appear.

## Missing files

A file that isn't there is a different problem from one you're not allowed to read. If Pro Tools shows the session's media as offline, relink it in Pro Tools; a permission won't help.
