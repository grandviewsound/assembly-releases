# Sound Rolls and the Deep Scan

Assembly identifies a clip by its audio, so first it needs to know the sound rolls.

## Scan the rolls

Choose **Scan Sound Rolls** in step 1, or **Sources ▸ Scan Sound Rolls…** (⌘O), and choose the folder that holds the production rolls. Step 1 then shows how many rolls it found; **View Library** (⌘2) lists them.

## Deep scan, once

Matching needs a **deep scan**: Assembly listens to every channel of every roll and saves what it hears to a database file. Choose **Deep Scan** in step 1, or **Sources ▸ Deep Scan Sound Rolls…** (⇧⌘D), and choose a folder for the database.

A drive of rolls takes a while, but it only happens once:

- When new rolls arrive, **Update Deep Scan** reads only the new or changed rolls and carries the rest forward.
- The database is the only file a deep scan writes. It can live anywhere you like; beside the rolls is convenient, because it travels with them.
- **Sources ▸ Open Database…** (⇧⌘I) opens a deep scan that already exists — one made earlier, or on another Mac.
- **Sources ▸ Choose New Database Location…** sets where the next deep scan is saved. The one in use stays in use until then.

> Every channel of a poly roll is scanned on its own, so a clip cut from a single iso mic still finds its roll and its channel.

## When the drive isn't there

Assembly remembers the rolls folder. Production drives spend a lot of time unplugged, so while the drive is away step 1 says so and offers to relink; plug the drive back in and Assembly picks up where it was.

- **Relink Sound Rolls** — the rolls moved, or their folder was renamed. Choose where they are now. The deep scan stays valid; nothing is scanned again.
- **Locate Deep Scan** — the database file itself moved. Choose where it is now.
- **Deep Scan Again** — start the database over.
- **Remove** — forget this folder, to work with a different one.

If step 1 says macOS or the folder's permissions refused access, see [Files and Permissions](help:file-access).
