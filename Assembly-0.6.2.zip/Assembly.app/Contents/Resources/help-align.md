# Aligning Lavs to the Boom

**Session ▸ Align Selected Clips…** lines up the radio mics with the boom, in time and in phase, so they sit together without comb filtering.

In Pro Tools, select the assembled clips you want aligned, and each take's boom with them: the lowest-numbered boom in a take is what the rest of it is aligned to. Then choose **Align Selected Clips…**. A sheet shows what will happen before anything is written.

## What it does

- Each lav and Boom 2 clip is aligned to its take's Boom 1.
- The aligned audio is written as new files in the session's Audio Files folder, named like an AudioSuite render: the clip's name followed by `-ALN_01`.
- The new files keep the roll's metadata, but get an identity of their own, so Pro Tools never relinks them to the original roll.
- The aligned set goes on new tracks, with each take's Boom 1 laid down unchanged beside it.

The original clips and the sound rolls are never touched.

## Options

- **Handles** — how many seconds of extra audio, up to 60, to align and write either side of each clip.
- **File name** and **Track name** — the names for the new files and tracks.
- **Folder** — put the aligned set in a folder track.
- **Track color** and **Clip color** — including a color for each kind of mic.

## Clips left alone

Some clips are left exactly as they are rather than moved on a guess:

- No boom from its take is in the selection.
- The boom gives nothing to align to — a dead boom, or one that never hears that actor.

The sheet lists how many clips are left alone and why, and the diagnostic report names each one.
