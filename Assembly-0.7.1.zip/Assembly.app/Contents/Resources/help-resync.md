# Resyncing Rolls Placed by Hand

Where Assembly couldn't assemble a clip, you can bring in its sound rolls yourself with Pro Tools' Field Recorder guide tracks. Those go by timecode, so they can sit a little off the reference. **Session ▸ Resync Selected Clips…** puts them back in sync, to the sample.

In Pro Tools, select the reference clip and the roll clips under it, across their tracks, then choose **Resync Selected Clips…** — in the Session menu, or the toolbar's **Match** button. A summary says what will change before anything is written.

## What it does

- Each roll clip is measured against the reference clip it sits under, by its audio. The reference can be the mix, a boom or a lav: Assembly finds which channel of the roll it is a copy of.
- All the clips of one roll under one reference move together, since a roll's channels share one clock.
- Each roll clip is replaced where it is, at the same length, playing from the right place in its roll. Its edges stay on the reference's cuts, and the clips beside it aren't touched.
- Afterwards Assembly reads the session back and checks every replaced clip, and that nothing else changed.

**Edit ▸ Undo** in Pro Tools takes a resync back.

## What it leaves alone

A take is put right whole or not at all, so its channels never end up out of sync with each other. The summary says why a take is left alone:

- **A fade or crossfade** on any of its clips. Fades aren't put back yet.
- **A clip it can't read**: its name has no channel ending such as `.A3`, or the track's name doesn't fit the channel.
- **A measurement too weak to act on**, or a slip the roll has no audio for.

Clips already in sync are left as they are.

## Good to know

- Pro Tools can't say what color a clip is, so the new clips are colored the way Assemble colors clips, from your clip color options. Clip gain on the old clips isn't kept.
- The new clips are named for their roll and channel, as Assemble names them, so they can be resynced or aligned again.
- The session is put in Slip while Resync writes, and back in your edit mode after.
- The rolls have to be in the project's sound rolls folder: that's how Assembly tells a roll from the reference.
