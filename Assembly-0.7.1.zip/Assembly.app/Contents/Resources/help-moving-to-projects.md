# Moving to Projects

From version 0.7, Assembly keeps each show in a [project](help:projects). If you used an earlier version, your deep scan moves into a project once, the first time you open 0.7. Nothing is scanned again, and your sound rolls aren't touched.

## Why it has to move

Earlier versions knew one deep scan at a time, remembered on your Mac, with one set of options for everything. That meant:

- Changing shows meant swapping the database and setting track names, colors and the script again by hand.
- Only one show could be open.
- Moving to another Mac meant finding the deep scan and setting everything up again.
- Assembly could only be opened from inside itself, never by double-clicking a show.

A project holds a show's deep scan and options in one file, so each show remembers its own, and you can open several and double-click them. Windows, options and the rolls folder now all belong to a project, so 0.7 can't work from a database on its own.

## What happens

When you open 0.7, Assembly asks to create the project. **Create Project** does this:

1. Makes a project beside your deep scan, with the same name.
2. Moves the deep scan into it, unchanged.
3. Puts your options, your rolls folder and the link to your script in it, and opens it.

If you'd rather not yet, choose **Quit**: nothing changes, and you can go back to your older version.

## Keeping a backup

**Keep the old database as a backup** leaves your old file where it was, under its old name. It's ticked whenever the drive has room.

- It uses no extra space on an APFS drive. On other drives, such as exFAT, it uses as much space as the deep scan.
- It's there in case you go back to an older version. It won't include rolls you scan later.
- Assembly never deletes it. Delete it yourself whenever you're happy with the project.

> With a large deep scan on an exFAT drive, keeping a backup is a long copy. Without one, the move takes a moment.

## If the deep scan isn't here

If its drive isn't connected, connect it and choose **Try Again**. **Find Deep Scan…** lets you point to the file. **Continue Without It** carries on, and Assembly asks again once the deep scan is back.

If the drive is read-only, Assembly can't put a project on it. Copy the `.asmbfp` file to a drive Assembly can write to, then open the copy.

## Other deep scans

Have more than one? Choose **File ▸ Open Project…** and pick the `.asmbfp` file, double-click it, or drop it on a window, and Assembly offers to make a project of it.

## Several Macs

Each Mac asks once. If a project of the same name is already beside the deep scan, perhaps made on another Mac, Assembly offers to open it instead of making another.

Older versions of Assembly can't open projects, so it's best if everyone on a show moves together.
