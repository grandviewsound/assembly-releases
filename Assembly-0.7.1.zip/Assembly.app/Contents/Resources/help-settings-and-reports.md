# Settings, Reports and Updates

## Settings

**Assembly ▸ Settings…** (⌘,) holds what belongs to the app rather than to a run:

- **Appearance** — System, Light or Dark.
- **Updates** — whether Assembly checks for updates by itself, and whether it downloads and installs them by itself.

Options that change what an assembly does sit beside it, in step 3.

## Sharing your options

Your options are saved with each [project](help:projects) as you change them. **File ▸ Export Settings…** saves your track naming, grouping, colors, heights, muting, report track, picture track and Align options to a file. A colleague chooses **File ▸ Import Settings…** to use the same ones. The file says nothing about any session, and carries no folder permissions; appearance and update choices stay on each Mac.

## Diagnostic reports

If something goes wrong, choose **Session ▸ Save Diagnostic Report…** (⇧⌘E), or the toolbar's **Diagnostic** button, and send the file. Save it right after the problem, before quitting, while Assembly still remembers the run.

The report is plain text, so you can read it before you share it. It names files and scenes from the run.

The **Diagnostics** menu holds tests for investigating a problem. Open the menu and hold Option to see them. Use them when asked to; some change the session for a moment.

## Updates

If you allowed it when Assembly asked, it checks for a new version about once a day. You can check any time with **Assembly ▸ Check for Updates…**, and change the choice in Settings.

An update is checked against Assembly's signing key before it installs, so only a genuine Assembly update is ever accepted. If one arrives while a scan, match or assembly is running, choose **Install When I Quit** and carry on.

## What's new

What each update brought, newest first. Notes start with 0.6.3.

**0.7.1** · November 8, 2026

- **New: Resync Selected Clips.** Sound rolls you bring in yourself with Field Recorder guide tracks can sit a little off the reference. Select the reference clip and the roll clips under it, then choose **Session ▸ Resync Selected Clips…**, or the same item in the toolbar's **Match** button. Assembly measures each take against the reference by its audio and puts it back in sync, to the sample. See [Resyncing Rolls Placed by Hand](help:resync).
  - Each roll clip is replaced at the same position and length, playing from the right place in its roll, so its edges stay on the picture cuts.
  - A summary says how far out each take is and what will change before anything is written. **Edit ▸ Undo** in Pro Tools takes it back.
  - Takes with fades are left alone for now, and the summary says so.
  - New clips are named and colored the way Assemble names and colors them. Clip gain on the old clips isn't kept.
- **Placement is exact in more cases.** A sync measurement could read one sample early, which could put a short clip a sample out.
- **A selection that starts just after a crossfade** now places its first clip at the true edit, not the middle of the fade.
- **A clip that follows a crossfade** keeps its exact end, and its fade out when you recreate fades.
- **Help lists what's new in each version**, here.

**0.7** · November 7, 2026

- **Assembly now uses projects.** A project keeps a show's deep scan, track names, colors and options in one file. Double-click it, or use **File ▸ Open Project…** or **Open Recent**. The first time 0.7 opened, it asked to move your deep scan into a project; nothing was scanned again. See [Moving to Projects](help:moving-to-projects).
- **Several projects at once**, each in its own window. They take turns with Pro Tools, and say so when one has to wait.
- **Options save themselves.** There's no Save: any option or color you change is in the project straight away, and a new project starts from the options you used last.
- **A new project goes in its rolls folder** unless you choose somewhere else, so it travels with the rolls.
- **The wrong project is caught.** If a session was last used in another project, Assembly says so before Match or Align.
- **A project links to its script** and never holds a copy.
- **Scan Sound Rolls is now ⇧⌘O.** ⌘O is Open Project. Open Database and Choose New Database Location have gone: a deep scan lives in its project.
- **The probes in the Diagnostics menu are out of the way.** Open the menu and hold Option to see them.
- Older versions of Assembly can't open projects.

**0.6.9** · November 6, 2026

- **Every toolbar button has its name under it:** Match, Align, Scene/Shot, Diagnostic and Help. Match and Scene/Shot are new, and drop down with their commands.
- **Connecting to Pro Tools has moved** to the Match button, and step 2 always says whether Assembly is connected, even before a scan.
- **An assembly's tracks can go in a folder.** A new option in the Tracks card, off until you turn it on.
- **Stop finishes the step it is on, then stops.** It used to report a connection failure at that step.
- **The custom track color no longer comes up empty.** If Pro Tools doesn't give Assembly its palette, the picker says so and tries again each time it opens.
- **The progress window says Aligning** rather than Assembling.

**0.6.8** · November 6, 2026

- **Scene numbers with a letter inside them now read.** Slates like `2A7-4` and `V2X38H-1` were missed, which left holes on the Scene track. Scripts that number scenes this way read too.
- **A 2 pop is no longer read as a scene.**
- **A warning when a script hardly fits the cut.** The review warns if the remembered script names almost none of the cut's scenes. **Clear** removes it.
- **The Align report track no longer marks flipped polarity.** The diagnostic report counts them instead.

**0.6.7** · November 5, 2026

- **Align Selected Clips no longer refuses clips that start one sample before a frame.** Assembled clips often start there.
- **A report track for alignments** marks each place worth looking at: NOT ALIGNED, LEFT ALONE, FAILED and CHECK, one entry per take. Turn it off with **Report** in the Align sheet.
- **When nothing can be aligned, an alert says why**, where before there was only a line in the status bar.

**0.6.6** · November 5, 2026

- **Color scenes by INT and EXT.** With the shooting script added, the **Scene color** choice gives INT, EXT and INT/EXT a color each. Shots set to **Same as its scene** take the scene's color, and **Shades of the scene color** gives each angle a shade of it.
- **Batch export no longer waits for Pro Tools.** When Assembly isn't connected, it reads the EDLs straight away; check the frame rate and sample rate in the review.
- **A Help button** at the right end of the main window's toolbar.

**0.6.5** · November 4, 2026

- **Batch Align Sound Rolls (Experimental)** aligns the lavs of whole sound rolls with no Pro Tools session, writing each roll to a destination in the same folders with your file-name text added. Every channel and the roll's metadata are kept, each copy gets a new UMID, and the rolls themselves are only read.
- **Three alignment modes:** Boom 1; most prominent boom (Experimental); and most prominent boom with the booms aligned too (Experimental).
- **An Align button in the toolbar** offers Align Selected Clips and Batch Align Sound Rolls.
- **Align Selected Clips is marked experimental.**

**0.6.4** · November 2, 2026

- **Scene tracks for series.** On slates that start with the episode, like `201-101C_02A`, the scene is read after the episode: scene 101, setup C.

**0.6.3** · November 2, 2026

- **Scene tracks from scene-first slates.** On slates like `15F-2A`, the letters after the scene number are read as the setup, so a scene cut across its setups is one scene clip.
- **Shot colors by angle follow the setup.** Every take and camera of one setup shares a color.
- **Leaders stay off the Scene track.**
- **Television reels.** A list whose leader runs up to first frame of action on the hour is no longer offered a placement an hour out.
