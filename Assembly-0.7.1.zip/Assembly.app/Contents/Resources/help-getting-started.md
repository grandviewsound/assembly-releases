# Getting Started

Assembly finds the original production sound behind the clips in a Pro Tools edit and lays it back into the session, placed to the sample. It also builds picture reference tracks from an EDL, and aligns lavs to the boom.

Each show is a [project](help:projects): its deep scan and options in one file, with a window of its own. The window works left to right in three steps. A step that isn't ready yet says what it's waiting for.

1. **Sound Rolls** — point Assembly at the folder of production sound rolls and deep scan it, once. See [Sound Rolls and the Deep Scan](help:sound-rolls).
2. **Match** — select clips or tracks in Pro Tools, then match them. Assembly connects to Pro Tools by itself. See [Matching](help:matching).
3. **Assemble** — choose how the new tracks are laid out, review what will happen, then assemble. See [Assembling](help:assembling).

> Assembly never changes your sound rolls. They are read, never written, renamed or added to, and the assembled clips refer to them where they are.

## What you need

- Pro Tools 2025.06 or later, running on this Mac, with the session open.
- The production sound rolls on a drive this Mac can read.
- macOS 14 (Sonoma) or later.

## Where things are

- **File** menu: **New Project** (⌘N), **Open Project…** (⌘O) and **Open Recent**.
- **Session** menu: connecting to Pro Tools, matching, picture tracks, Align, and saving a diagnostic report.
- **Sources** menu: scanning the sound rolls and the deep scan.
- **Window** menu: **Source Library** (⌘2) lists the rolls; **Match Detail** (⌘3) lists every matched and unmatched clip. Both are for the project at the front.
- **Assembly ▸ Settings…** (⌘,): appearance and updates.
- **File ▸ Export Settings…**: share your options with colleagues. See [Settings, Reports and Updates](help:settings-and-reports).
- **Toolbar**: **Match**, **Align** and **Scene/Shot** each drop down with their commands; **Diagnostic** saves a report.
- **Help ▸ Assembly Help** (⌘?), or the **Help** button at the right end of the main window's toolbar, opens these pages.
