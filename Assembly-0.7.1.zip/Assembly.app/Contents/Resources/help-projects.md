# Projects

Used Assembly before 0.7? See [Moving to Projects](help:moving-to-projects).

A project keeps a show's deep scan and options together in one file, `Name.assembly`. It looks like a single file in Finder: double-click it to open it, and move or copy it like any other file. Your sound rolls stay where they are; a project only knows where to find them.

## Starting and opening

- **File ▸ New Project** (⌘N) opens a new window. Scan your sound rolls in step 1; the first deep scan asks you to name the project and choose where it goes, starting inside the rolls folder.
- **File ▸ Open Project…** (⌘O), **File ▸ Open Recent**, or a double-click opens one.
- Assembly opens what you had open when you quit. If nothing was open, the Welcome window lists your recent projects. **Window ▸ Welcome to Assembly** brings it back.

There is no Save. Any option or color you change is saved with the project straight away, and a new project starts from the options you used last.

> A project on a drive that's unplugged stays in the Welcome list, and opens once the drive is back. If its drive leaves while it's open, changes are saved when the drive returns.

## Several projects at once

Each project has its own window, with its own sound rolls and options, and its own **Source Library**, **Match Detail** and **Batch Align Sound Rolls** windows. The menus act on the project at the front.

There's only one Pro Tools, so projects take turns with it:

- Any project can match, but only one at a time can read the selection or write to the session. While one does, the others say so and wait for you to try again.
- Only one deep scan or batch alignment runs at a time, because they fight over the drive.

## The right project

If the session open in Pro Tools was last used in another project, Assembly says so before **Match** or **Align**. **Match Anyway** or **Align Anyway** carries on, and that session then belongs to this project.

If a match finds almost nothing while another project is open, step 2 asks whether this is the right one.

## Closing

A project with work running won't close: wait for the work to finish or stop it first. Quitting says what would be cut off and lets you choose.

## The script

A project links to its shooting script and never holds a copy, so passing a project to someone doesn't pass the script with it. If the script isn't where the link says, Assembly asks you to choose it again.
