# Sound Rolls and the Deep Scan

Assembly identifies a clip by its audio, so first it needs to know the sound rolls.

## Scan the rolls

Choose **Scan Sound Rolls** in step 1, or **Sources ▸ Scan Sound Rolls…** (⇧⌘O), and choose the folder that holds the production rolls. Step 1 then shows how many rolls it found; **View Library** (⌘2) lists them.

## Deep scan, once

Matching needs a **deep scan**: Assembly listens to every channel of every roll and saves what it hears inside the [project](help:projects). Choose **Deep Scan** in step 1, or **Sources ▸ Deep Scan Sound Rolls…** (⇧⌘D). The first one asks you to name the project and choose where it goes.

A drive of rolls takes a while, but it only happens once:

- When new rolls arrive, **Update Deep Scan** reads only the new or changed rolls and carries the rest forward.
- The project is the only file a deep scan writes. Assembly suggests the rolls folder itself, so the project goes wherever the rolls are copied or moved, but it can live anywhere you like. Scanning passes over it.
- A deep scan from before 0.7, a file ending in `.asmbfp`, becomes a project when you open it. See [Moving to Projects](help:moving-to-projects).

> Every channel of a poly roll is scanned on its own, so a clip cut from a single iso mic still finds its roll and its channel.

## When the drive isn't there

Assembly remembers the rolls folder. Production drives spend a lot of time unplugged, so while the drive is away step 1 says so and offers to relink; plug the drive back in and Assembly picks up where it was.

- **Relink Sound Rolls** — the rolls moved, or their folder was renamed. Choose where they are now. The deep scan stays valid; nothing is scanned again.
- **Deep Scan Again** — start the deep scan over, when it can't be read.

Other rolls belong in another project: choose **File ▸ New Project** (⌘N).

If step 1 says macOS or the folder's permissions refused access, see [Files and Permissions](help:file-access).
