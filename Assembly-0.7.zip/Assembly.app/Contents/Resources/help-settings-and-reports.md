# Settings, Reports and Updates

## Settings

**Assembly ▸ Settings…** (⌘,) holds what belongs to the app rather than to a run:

- **Appearance** — System, Light or Dark.
- **Updates** — whether Assembly checks for updates by itself, and whether it downloads and installs them by itself.

Options that change what an assembly does sit beside it, in step 3.

## Sharing your options

Your options are saved with each [project](help:projects) as you change them. **File ▸ Export Settings…** saves your track naming, grouping, colors, heights, muting, report track, picture track and Align options to a file. A colleague chooses **File ▸ Import Settings…** to use the same ones. The file says nothing about any session, and carries no folder permissions; appearance and update choices stay on each Mac.

## Diagnostic reports

If something goes wrong, choose **Session ▸ Save Diagnostic Report…** (⇧⌘E), or the toolbar's **Diagnostic** button, and send the file. Save it right after the problem, before quitting, while Assembly still remembers the run.

The report is plain text, so you can read it before you share it. It names files and scenes from the run.

The **Diagnostics** menu holds tests for investigating a problem. Open the menu and hold Option to see them. Use them when asked to; some change the session for a moment.

## Updates

If you allowed it when Assembly asked, it checks for a new version about once a day. You can check any time with **Assembly ▸ Check for Updates…**, and change the choice in Settings.

An update is checked against Assembly's signing key before it installs, so only a genuine Assembly update is ever accepted. If one arrives while a scan, match or assembly is running, choose **Install When I Quit** and carry on.
